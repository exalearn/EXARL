import matplotlib.pyplot as plt
import numpy as np

labels = ['8','16','32','64','128']

#Metric: Training time
p1 = [16.22400856,15.88909435,15.63636255,15.08471465,12.38950276]
p2 = [14.71609211,14.08397913,13.97058034,13.85658813,11.17521763]
p4 = [12.41890097,12.39591575,12.41358304,12.33888412,9.365462303]
p8 = [11.18980193,11.20243192,13.81796265,11.08084059,0]
p16 = [0,10.60383677,13.44705081,13.21804976,0]
p32 = [0,0,10.48782706,0,0]

x = np.arange(len(labels)) # the label locations
width = 0.1 # the width of the bars

fig, ax = plt.subplots()
rects1 = ax.bar(x - (3*width), p1,width, label='1 learner')
rects2 = ax.bar(x - (2*width), p2,width, label='2 learners')
rects3 = ax.bar(x - width, p4,width, label='4 learners')
rects4 = ax.bar(x, p8,width, label='8 learners')
rects4 = ax.bar(x + width, p16,width, label='16 learners')
rects4 = ax.bar(x + (2*width), p32,width, label='32 learners')


#Add some text for labels, title and custom x-axis tick labels, etc.
#ax.set_ylabel('Training time(in seconds)')
ax.set_ylabel('Training time')
ax.set_xlabel('Number of actors')
ax.set_title('Total Training time (ExaBooster LSTM-MLDQN agent)')
#ax.set_title('generate_data method (LSTM-DQN agent)')
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.legend()

ax.bar_label(rects1,padding=2)
ax.bar_label(rects2,padding=2)
ax.bar_label(rects3,padding=2)
ax.bar_label(rects4,padding=2)

#fig.tight_layout()

#plt.show()
#plt.savefig('mlasync-lstm-dqn-trainingtime-results-final.png')
plt.savefig('mlasync-lstm-mldqn-ExaBooster-trainingtime-results-final.png')
#plt.savefig('lstm-dqn-scalingresults-final.png')
