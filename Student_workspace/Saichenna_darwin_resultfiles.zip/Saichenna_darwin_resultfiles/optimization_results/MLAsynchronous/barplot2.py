import matplotlib.pyplot as plt
import numpy as np

labels = ['8','16']

#p1 = [16.275,16.642]
#p2 = [14.470,14.821]
#p4 = [12.705,13.857]
#p8 = [11.350,12.747]

p1 = [122.491,120.154]
p2 = [138.010,135.003]
p4 = [157.490,144.974]
p8 = [176.046,157.334]

x = np.arange(len(labels)) # the label locations
width = 0.1 # the width of the bars

fig, ax = plt.subplots()
rects1 = ax.bar(x - (2*width), p1,width, label='1 learner')
rects2 = ax.bar(x - width, p2,width, label='2 learners')
rects3 = ax.bar(x, p4,width, label='4 learners')
rects4 = ax.bar(x + width, p8,width, label='8 learners')

#Add some text for labels, title and custom x-axis tick labels, etc.
#ax.set_ylabel('Training time(in seconds)')
ax.set_ylabel('Training throughput(batches trained per second)')
ax.set_xlabel('Number of actors')
ax.set_title('Training throughput (LSTM-DQN agent)')
#ax.set_title('generate_data method (LSTM-DQN agent)')
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.legend()

ax.bar_label(rects1,padding=3)
ax.bar_label(rects2,padding=3)
ax.bar_label(rects3,padding=3)
ax.bar_label(rects4,padding=3)

fig.tight_layout()

#plt.show()
#plt.savefig('mlasync-lstm-dqn-trainingtime-results-final.png')
plt.savefig('mlasync-lstm-dqn-trainingthroughput-results-final.png')
#plt.savefig('lstm-dqn-scalingresults-final.png')
