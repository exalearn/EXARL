#Sai Chenna
#This script evaluates the efficiency of two window-selection algorithms used by the learner(s) to select a specific RMA window of the learner

from mpi4py import MPI
import numpy as np
import sys
from collections import Counter
#import exarl as erl
#import exarl.mpi_settings as mpi_settings
# MPI communicator
global_comm = MPI.COMM_WORLD
global_rank = global_comm.Get_rank()
global_size = global_comm.Get_size()
num_learners = global_size
nepisodes = 1000
nsteps = 200
learner_procs = num_learners
actor_procs = 128

def random_window_selector():
    low = 0  # start
    high = actor_procs  # stop + 1
    s = np.random.randint(low=low, high=high, size=1)
    return s[0]

def range_window_selector():
    size = int(actor_procs/learner_procs)
    offset = actor_procs % learner_procs
    first_offset = size + offset

    if global_rank == 0:
        low = learner_procs
        high = learner_procs + first_offset
    else:
        low = learner_procs + first_offset+((global_rank-1)*size)
        high = learner_procs + first_offset+((global_rank)*size)

    s = np.random.randint(low=low,high=high)

    return s


#Sanity check
if global_rank == 0:
    print("Total number of processes: {}".format(global_size))
    print("Total number of learners: {}".format(learner_procs))
    print("Total number of actors: {}".format(actor_procs))

data = dict()
newdata = dict()
counter = 0
for i in range(nepisodes):
    for j in range(nsteps):
        data[(i,j)] = random_window_selector()
        #data[(i,j)] = range_window_selector()
        tmp = global_comm.gather(data[(i,j)],root=0)
        #if global_rank == 0:
        #    print(tmp)

        if global_rank == 0:
            val = Counter(tmp)
            for k,v in val.items():
                if v > 1:
                    counter += 1
                    #print(tmp)
                    break


global_comm.Barrier()
if global_rank == 0:
    print("No of times multiple learners read from the same window : {}".format(counter))
    print("Percentage of times this happening : {}".format((counter*100)/(nepisodes*nsteps)))
sys.exit()
