#Sai Chenna
#This script evaluates the efficiency of two window-selection algorithms used by the learner(s) to select a specific RMA window of the learner

from mpi4py import MPI
import numpy as np
import sys
#import exarl as erl
#import exarl.mpi_settings as mpi_settings
# MPI communicator
global_comm = MPI.COMM_WORLD
global_rank = global_comm.Get_rank()
global_size = global_comm.Get_size()
num_learners = 4
nepisodes = 100
nsteps = 100
epochs = 5
learner_procs = num_learners
actor_procs = global_size - learner_procs
#For algo2 calculation:
size = int(actor_procs/learner_procs)
offset = actor_procs % learner_procs
first_offset = size + offset
def algo2():
    val = dict()
    if learner_comm.rank == 0:
        low = learner_procs
        high = learner_procs + first_offset
    else:
        low = learner_procs + first_offset+((learner_comm.rank-1)*size)
        high = learner_procs + first_offset+((learner_comm.rank)*size)

    for j in range(nepisodes):
        for k in range(nepisodes):
            s = np.random.randint(low=low,high=high)
            val[s] = val.get(s,0)+1
    return val


def algo1():
    val = dict()
    low = learner_procs
    high = agent_comm.size
    for j in range(nepisodes):
        for k in range(nepisodes):
            s = np.random.randint(low=low,high=high)
            val[s] = val.get(s,0)+1
    return val

# Function to test if a process is a learner
def is_learner():
    try:
        if agent_comm.rank < num_learners:
            return True
    except:
        return False



procs_per_env = 1
# Learner communicator
learner_color = MPI.UNDEFINED
if global_rank < num_learners:
    learner_color = 0
learner_comm = global_comm.Split(learner_color, global_rank)

# Agent communicator
global agent_comm
agent_color = MPI.UNDEFINED
if (global_rank < num_learners) or ((global_rank + procs_per_env - num_learners) % procs_per_env == 0):
    agent_color = 0
agent_comm = global_comm.Split(agent_color, global_rank)



#Sanity check
print("Total number of processes: {}".format(global_size))
print("Total number of learners: {}".format(learner_procs))
print("Total number of actors: {}".format(actor_procs))

for i in range(epochs):
    if is_learner():
        #counter = algo1()
        counter = algo2()
        data = np.zeros(actor_procs)

        for i in range(learner_procs,agent_comm.size):
            count = counter.get(i,0)
            data[i-learner_procs] = count

        learner_comm.Barrier()

        if learner_comm.rank == 0:
            totals = np.zeros_like(data)
        else:
            totals = None

        learner_comm.Reduce(data,totals,op=MPI.SUM,root=0)


        if learner_comm.rank == 0:
            with open('algo2-output-run3.csv','a') as f:
                f.write(str(int(totals[0])))
                for i in range(1,len(totals)):
                    f.write(","+str(int(totals[i])))
                f.write("\n")

global_comm.Barrier()
sys.exit("Done!")
