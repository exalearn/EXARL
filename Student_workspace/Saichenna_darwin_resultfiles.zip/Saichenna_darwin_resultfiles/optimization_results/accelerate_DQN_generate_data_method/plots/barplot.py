import matplotlib.pyplot as plt
import numpy as np

labels = ['32','64','128']
p1 = [2.297741,4.493223,9.048644]
p2 = [1.154635,2.281863,3.365393]
p4 = [0.594148,1.168219,2.331339]
p8 = [0.321839,0.615316,1.187188]

#p1 = [2.170231,4.377755,8.598639]
#p2 = [1.18763,2.343856,3.518729]
#p4 = [0.594148,1.216336,2.380034]
#p8 = [0.333644,0.638636,1.244069]


x = np.arange(len(labels)) # the label locations
width = 0.1 # the width of the bars

fig, ax = plt.subplots()
rects1 = ax.bar(x - (2*width), p1,width, label='1 process')
rects2 = ax.bar(x - width, p2,width, label='2 process')
rects3 = ax.bar(x, p4,width, label='4 process')
rects4 = ax.bar(x + width, p8,width, label='8 process')

#Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_ylabel('Average execution time(in seconds)')
ax.set_title('generate_data method (MLP-DQN agent)')
#ax.set_title('generate_data method (LSTM-DQN agent)')
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.legend()

ax.bar_label(rects1,padding=3)
ax.bar_label(rects2,padding=3)
ax.bar_label(rects3,padding=3)
ax.bar_label(rects4,padding=3)

fig.tight_layout()

#plt.show()
plt.savefig('mlp-dqn-scalingresults-final.png')
#plt.savefig('lstm-dqn-scalingresults-final.png')
