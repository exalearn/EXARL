import matplotlib.pyplot as plt
import numpy as np

labels = ['32','64']

#serial = [257.7736,336.1653]
#parallel = [75.1740,105.6571]

serial = [251.3525,339.5682]
parallel = [89.0673,122.7576]

x = np.arange(len(labels)) # the label locations
width = 0.1 # the width of the bars

fig, ax = plt.subplots()
#ects1 = ax.bar(x - (2*width), p1,width, label='1 process')
rects1 = ax.bar(x - width, serial,width, label='serial')
rects2 = ax.bar(x, parallel,width, label='parallel')
#ects4 = ax.bar(x + width, p8,width, label='8 process')

#Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_ylabel('Execution time(in seconds)')
ax.set_title('Training LSTM-DQN agent (episode count 64; steps per episode 100)')
#ax.set_title('generate_data method (LSTM-DQN agent)')
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.legend()

ax.bar_label(rects1,padding=3)
ax.bar_label(rects2,padding=3)
#ax.bar_label(rects3,padding=3)
#ax.bar_label(rects4,padding=3)

fig.tight_layout()

#plt.show()
plt.savefig('lstm-dqn-trainingresults.png')
#plt.savefig('lstm-dqn-scalingresults.png')
