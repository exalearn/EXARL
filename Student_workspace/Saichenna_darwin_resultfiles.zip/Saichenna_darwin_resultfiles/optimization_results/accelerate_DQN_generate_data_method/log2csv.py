

filename = "serial_generatedata_dqn_mlp_bz256"
fin = open(filename+".log",'r')
fout = open(filename+".csv",'a')

log = []

for line in fin:
    line = line.rstrip()
    ls = line.split()
    val = float(ls[-1][:-1])
    log.append(val)


fin.close()
#print(log)
i=0
for t in log:
    if i==0:
        fout.write(str(t))
        i=i+1
    else:
        fout.write(","+str(t))
fout.close()
